﻿namespace WebAsos.Data.Entitties.DTO
{
    public class ProductImageUploadDTO
    {
        public string Data { get; set; }
        public string Extension { get; set; }
    }
}
