﻿namespace WebAsos.Data.Entitties.DTO
{
    public class EmailSettings
    {
        public string User { get; set; }
        public string Password { get; set; }
        public string SMTP { get; set; }
        public int PORT { get; set; }
        public string From { get; set; }
    }
}
