﻿namespace WebAsos.Data.Entitties.DTO
{
    public class UploadImageDTO
    {
        public string[] Photos { get; set; }
    }
}
