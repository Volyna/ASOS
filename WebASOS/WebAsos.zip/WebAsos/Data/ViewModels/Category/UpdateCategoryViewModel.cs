﻿namespace WebAsos.Data.ViewModels.Category
{
    public class UpdateCategoryViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        //public string ImageBase64 { get; set; }
    }
}
