﻿namespace WebAsos.Data.ViewModels.User
{
    public class BeforeLoginUser
    {
        public string Email { get; set;}
    }
}
