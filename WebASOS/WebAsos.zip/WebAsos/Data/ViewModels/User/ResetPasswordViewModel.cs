﻿namespace WebAsos.Data.ViewModels.User
{
    public class ResetPasswordViewModel
    {
        public string Email { get; set; }
    }
}
