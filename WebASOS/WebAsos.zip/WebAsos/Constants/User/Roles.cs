﻿using System;
namespace WebAsos.Constants.User
{
    public static class Roles
    {
        
        public const string User = "user";
        public const string Admin = "admin";
    }
}

