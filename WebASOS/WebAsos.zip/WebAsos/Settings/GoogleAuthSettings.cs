﻿namespace WebAsos.Settings
{
    public class GoogleAuthSettings
    {
        public string ClientId { get; set; }
    }
}
