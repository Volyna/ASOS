﻿namespace WebAsos.Models
{
    public class ProductImageViewModel
    {
        public int Id { get; set; }
        public int Priority { get; set; }
        public bool IsMainImage { get; set; }
        public string Image { get; set; }
    }
}
