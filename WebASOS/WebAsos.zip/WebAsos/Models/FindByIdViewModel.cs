﻿namespace WebAsos.Models
{
    public class FindByIdViewModel
    {
        public int Id { get; set; }
    }
}
